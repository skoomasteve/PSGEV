﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Removes the God's Eye View installation.
.DESCRIPTION
  Stops any running dev server, deletes the install directory
  (including node_modules and your .env with API keys), and
  optionally removes the auto-stop scheduled task.
  Does NOT touch Node.js, Git, or anything outside the install dir.
.EXAMPLE
  .\Uninstall-GEV.ps1                    # interactive, backs up .env
  .\Uninstall-GEV.ps1 -KeepEnv           # keep .env as backup
  .\Uninstall-GEV.ps1 -Force             # non-interactive, delete everything
#>

param(
    [string]$InstallDir = "$HOME\godseyeview",
    [switch]$KeepEnv,   # keep .env (API keys) as a backup
    [switch]$Force      # skip confirmation prompts
)

$ErrorActionPreference = "Stop"

Write-Host "==> God's Eye View uninstaller" -ForegroundColor Cyan

if (-not (Test-Path $InstallDir)) {
    Write-Host "Nothing installed at $InstallDir - nothing to do." -ForegroundColor Yellow
    exit 0
}

# --- 1. Kill any running dev server for this install ---
Write-Host "Stopping any running server instances..."
$stoppedCount = 0
Get-CimInstance Win32_Process -Filter "Name='node.exe'" |
    Where-Object { $_.CommandLine -like "*$InstallDir*" } |
    ForEach-Object {
        $cmdSnippet = ($_.CommandLine).Substring(0, [Math]::Min(60, $_.CommandLine.Length))
        Write-Host "    Killing PID $($_.ProcessId) ($cmdSnippet...)"
        Stop-Process -Id $_.ProcessId -Force
        $stoppedCount++
    }
if ($stoppedCount -eq 0) { Write-Host "    No running GEV servers found." -ForegroundColor Gray }

# --- 2. Optionally back up .env before deletion ---
if ($KeepEnv -and (Test-Path "$InstallDir\.env")) {
    $backup = "$HOME\Desktop\godseyeview-.env-backup.$(Get-Date -Format 'yyyyMMdd-HHmmss').txt"
    Copy-Item "$InstallDir\.env" $backup
    Write-Host "    .env backed up to $backup" -ForegroundColor Green
} elseif (Test-Path "$InstallDir\.env") {
    if (-not $Force) {
        $answer = Read-Host ".env contains your API keys. Back it up to Desktop before deleting? (y/n)"
    } else {
        $answer = 'y'
    }
    if ($answer -eq 'y') {
        Copy-Item "$InstallDir\.env" "$HOME\Desktop\godseyeview-.env-backup.$(Get-Date -Format 'yyyyMMdd-HHmmss').txt" -Force
        Write-Host "    .env backed up to Desktop" -ForegroundColor Green
    } else {
        Write-Host "    .env will be deleted along with everything else" -ForegroundColor Yellow
    }
}

# --- 3. Delete the install directory ---
Write-Host "Deleting $InstallDir ..."
# Clear read-only flags (helps with stubborn node_modules)
attrib -r "$InstallDir\*" /s /d 2>$null

Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue

# Fallback for locked/path-length issues (Windows \\?\ trick)
if (Test-Path $InstallDir) {
    Remove-Item "\\?\$InstallDir" -Recurse -Force -ErrorAction SilentlyContinue
}

if (Test-Path $InstallDir) {
    Write-Fail "Could not fully delete $InstallDir. Some files may remain." -ForegroundColor Red
    Write-Host "    Close any programs using it, or manually delete in Explorer."
} else {
    Write-Host "    Removed." -ForegroundColor Green
}

# --- 4. Remove the auto-stop scheduled task if present ---
if (Get-ScheduledTask -TaskName "GEV-AutoStop" -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName "GEV-AutoStop" -Confirm:$false
    Write-Host "    Scheduled task 'GEV-AutoStop' removed." -ForegroundColor Green
}

# --- 5. Remove the watchdog script ---
$watchdogPath = "$HOME\godseyeview-watchdog.ps1"
if (Test-Path $watchdogPath) {
    Remove-Item $watchdogPath -Force
    Write-Host "    Watchdog script $watchdogPath removed." -ForegroundColor Gray
}

Write-Host "`nUninstall complete." -ForegroundColor Green
Write-Host "Note: Node.js and Git were left installed. Remove manually if desired:"
Write-Host "  winget uninstall OpenJS.NodeJS.LTS    OR    choco uninstall nodejs-lts"
Write-Host "  winget uninstall Git.Git              OR    choco uninstall git.install"