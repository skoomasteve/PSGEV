﻿@echo off
setlocal

REM ============================================================
REM  God's Eye View - Double-click server launcher
REM  Server location defaults to ..\godseyeview relative to
REM  this .bat (i.e., the folder NEXT TO gev-tools), but can
REM  be overridden below or by keeping the old absolute path.
REM  Close this console window (or Ctrl+C) to stop.
REM ============================================================

REM %~dp0 ends with a backslash, so "..\" resolves cleanly
set "TOOLSDIR=%~dp0"
set "INSTALLDIR=%TOOLSDIR%..\godseyeview"

if not exist "%INSTALLDIR%\package.json" (
    echo [ERROR] Not installed at %INSTALLDIR%
    echo         Run the installer first.
    pause
    exit /b 1
)

echo Starting God's Eye View...
echo Server: http://localhost:4173  ^(or the port shown below^)
echo Close this window to stop the server.
echo.

REM resolve the ..\ path so the browser/menu shows a clean location
for %%I in ("%INSTALLDIR%") do set "INSTALLDIR=%%~fI"

cd /d "%INSTALLDIR%"
start "" http://localhost:4173
call npm run dev

endlocal