﻿#Requires -Version 5.1
<#
.SYNOPSIS
  God's Eye View system tray controller.
.DESCRIPTION
  Sits in the tray: start/stop/restart the GEV server (hidden background
  process with logging), open the app, run key signup/configure helpers,
  doctor, log viewer, README, reset settings, and manage Windows startup
  (Tray+GEV or Tray-only).
.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\GEV-Tray.ps1            # tray only
  powershell -ExecutionPolicy Bypass -File .\GEV-Tray.ps1 -StartGEV  # tray + server
#>

param(
    [string]$InstallDir = "$HOME\godseyeview",
    [string]$ScriptDir  = $(if ($PSScriptRoot) { $PSScriptRoot } else { "$HOME\gev-tools" }),
    [switch]$StartGEV   # when launched at boot: also start the server
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$logFile    = Join-Path $InstallDir "gev-server.log"
$envFile    = Join-Path $InstallDir ".env"
$readmePath = Join-Path $ScriptDir "GEV-README.txt"
$startupDir = [Environment]::GetFolderPath("Startup")
$trayPath   = Join-Path $ScriptDir "GEV-Tray.ps1"

# ---------------------------------------------------------------------------
# Server process management (hidden, logged, matched by install dir)
# ---------------------------------------------------------------------------
function Get-GEVProcesses {
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like "*$InstallDir*" }
}

function Test-GEVRunning { @(Get-GEVProcesses).Count -gt 0 }

function Start-GEVServer {
    if (Test-GEVRunning) { Show-Balloon "Already running"; return }
    if (-not (Test-Path (Join-Path $InstallDir "package.json"))) {
        [System.Windows.Forms.MessageBox]::Show("GEV not found at $InstallDir. Run the installer first.",
            "God's Eye View", "OK", "Warning") | Out-Null
        return
    }
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @(
        "-NoProfile","-ExecutionPolicy","Bypass","-Command",
        "Set-Location '$InstallDir'; npm run dev *>> '$logFile'"
    )
    Show-Balloon "Server starting... will be on http://localhost:4173 shortly."
    Start-Sleep -Seconds 2   # give the timer something to reflect
}

function Stop-GEVServer {
    $procs = @(Get-GEVProcesses)
    if ($procs.Count -eq 0) { Show-Balloon "Not running"; return }
    $procs | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Show-Balloon "Server stopped."
}

function Restart-GEVServer { Stop-GEVServer; Start-Sleep -Seconds 1; Start-GEVServer }

# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------
function Show-Balloon([string]$msg) {
    $script:notifyIcon.BalloonTipTitle = "God's Eye View"
    $script:notifyIcon.BalloonTipText  = $msg
    $script:notifyIcon.ShowBalloonTip(2500)
}

function Run-Helper([string]$psFile, [string]$windowTitle) {
    # Run a helper script in a VISIBLE console so prompts are answerable;
    # the tray stays alive meanwhile.
    if (-not (Test-Path $psFile)) {
        [System.Windows.Forms.MessageBox]::Show("Helper not found: $psFile", $windowTitle, "OK", "Warning") | Out-Null
        return
    }
    Start-Process powershell.exe -ArgumentList @(
        "-NoProfile","-ExecutionPolicy","Bypass","-File",$psFile
    ) -WorkingDirectory $ScriptDir
}

function Show-Log {
    if (Test-Path $logFile) { Start-Process notepad.exe -ArgumentList "`"$logFile`"" }
    else { Show-Balloon "No log yet (server never started)." }
}

function Show-Readme {
    if (Test-Path $readmePath) { Start-Process notepad.exe -ArgumentList "`"$readmePath`"" }
    else { Show-Balloon "README not found at $readmePath" }
}

# ---------------------------------------------------------------------------
# Windows startup management
# ---------------------------------------------------------------------------
function Get-BootShortcut([string]$name) { Join-Path $startupDir "$name.lnk" }

function Set-StartupMode([string]$mode) {   # 'full' | 'tray' | 'off'
    foreach ($name in @("GEV Tray","GEV Tray + Server")) {
        $sc = Get-BootShortcut $name
        if (Test-Path $sc) { Remove-Item $sc -Force }
    }
    if ($mode -eq 'off') { Show-Balloon "Autostart disabled."; return }

    $shell = New-Object -ComObject WScript.Shell
    $linkName = if ($mode -eq 'full') { "GEV Tray + Server" } else { "GEV Tray" }
    $sc = $shell.CreateShortcut((Get-BootShortcut $linkName))
    $sc.TargetPath = "powershell.exe"
    $args = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$trayPath`""
    if ($mode -eq 'full') { $args += " -StartGEV" }
    $sc.Arguments   = $args
    $sc.WindowStyle = 7   # minimized
    $sc.Save()
    Show-Balloon "Autostart set: $linkName"
}

function Test-StartupMode {
    if (Test-Path (Get-BootShortcut "GEV Tray + Server")) { return "full" }
    if (Test-Path (Get-BootShortcut "GEV Tray"))          { return "tray" }
    return "off"
}

# ---------------------------------------------------------------------------
# Menu item helper (PS 5.1-safe: Items.Add(text, scriptblock) does NOT bind
# the scriptblock as a click handler — it tries to cast it to an Image.
# So: create the item, then attach the handler with Add_Click.)
# ---------------------------------------------------------------------------
function Add-MenuItem($targetMenu, [string]$text, $action) {
    $item = $targetMenu.Items.Add($text)
    if ($action) { $item.Add_Click($action) }
    return $item
}

function Add-SubMenu($targetMenu, [string]$text) {
    $sub = New-Object System.Windows.Forms.ToolStripMenuItem($text)
    [void]$targetMenu.Items.Add($sub)
    return $sub
}

function Add-SubItem($subMenu, [string]$text, $action) {
    $item = $subMenu.DropDownItems.Add($text)
    if ($action) { $item.Add_Click($action) }
    return $item
}

# ---------------------------------------------------------------------------
# Build the tray icon + menu
# ---------------------------------------------------------------------------
$script:notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Icon    = [System.Drawing.SystemIcons]::Information   # no .ico file needed
$notifyIcon.Text    = "God's Eye View"
$notifyIcon.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip

# --- status line (updated by timer) ---
$mStatus = Add-MenuItem $menu "○ Server stopped" $null
$mStatus.Enabled = $false

$menu.Items.Add("-") | Out-Null

# --- server controls ---
[void](Add-MenuItem $menu "▶ Start server"   { Start-GEVServer })
[void](Add-MenuItem $menu "■ Stop server"    { Stop-GEVServer })
[void](Add-MenuItem $menu "↻ Restart server" { Restart-GEVServer })
[void](Add-MenuItem $menu "🌐 Open in browser" { Start-Process "http://localhost:4173" })

$menu.Items.Add("-") | Out-Null

# --- API management submenu ---
$apiMenu = Add-SubMenu $menu "🔑 API keys"
[void](Add-SubItem $apiMenu "Acquire API keys (signup portals)" {
    Run-Helper (Join-Path $ScriptDir "Start-GEV-KeySignups.ps1") "API signups"
})
[void](Add-SubItem $apiMenu "Enter / update API keys" {
    Run-Helper (Join-Path $ScriptDir "Configure-GEV-Keys.ps1") "Key configurator"
})
[void](Add-SubItem $apiMenu "Run setup doctor" {
    Run-Helper (Join-Path $ScriptDir "Run-Doctor.ps1") "Doctor"
})
[void](Add-SubItem $apiMenu "Edit .env directly" {
    Start-Process notepad.exe -ArgumentList "`"$envFile`""
})

$menu.Items.Add("-") | Out-Null

# --- Windows startup submenu ---
$bootMenu = Add-SubMenu $menu "🚀 Start with Windows"
[void](Add-SubItem $bootMenu "Tray + GEV server"     { Set-StartupMode 'full' })
[void](Add-SubItem $bootMenu "Tray only (no server)" { Set-StartupMode 'tray' })
[void](Add-SubItem $bootMenu "Disabled"               { Set-StartupMode 'off'  })

$menu.Items.Add("-") | Out-Null

# --- utilities ---
[void](Add-MenuItem $menu "📋 View server log" { Show-Log })
[void](Add-MenuItem $menu "📖 View README"      { Show-Readme })
[void](Add-MenuItem $menu "⚠ Reset ALL settings" {
    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "This deletes your .env (all API keys and configuration) and restores the default template.`n`nnode_modules and your repo are NOT touched. Continue?",
        "God's Eye View - Reset", "YesNo", "Warning")
    if ($confirm -eq 'Yes') {
        if (Test-Path (Join-Path $InstallDir ".env.example")) {
            Stop-GEVServer
            Copy-Item (Join-Path $InstallDir ".env.example") $envFile -Force
            icacls $envFile /inheritance:r /grant:r "$env:USERNAME`:F" | Out-Null
            Show-Balloon "Settings reset to defaults (server stopped)."
        } else { Show-Balloon ".env.example not found." }
    }
})

$menu.Items.Add("-") | Out-Null

# --- exit ---
[void](Add-MenuItem $menu "Exit" {
    if (Test-GEVRunning) {
        $c = [System.Windows.Forms.MessageBox]::Show(
            "Server is running. Stop it too?", "God's Eye View", "YesNoCancel", "Question")
        if ($c -eq 'Cancel') { return }
        if ($c -eq 'Yes') { Stop-GEVServer }
    }
    $notifyIcon.Visible = $false
    [System.Windows.Forms.Application]::Exit()
})

$notifyIcon.ContextMenuStrip = $menu

# --- double-click = open app / start server ---
$notifyIcon.Add_DoubleClick({
    if (-not (Test-GEVRunning)) { Start-GEVServer } else { Start-Process "http://localhost:4173" }
})

# --- periodic status refresh (menu text + icon tooltip) ---
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 5000
$timer.Add_Tick({
    if (Test-GEVRunning) {
        $mStatus.Text     = "● Server running"
        $notifyIcon.Text  = "God's Eye View - running"
    } else {
        $mStatus.Text     = "○ Server stopped"
        $notifyIcon.Text  = "God's Eye View - stopped"
    }
})
$timer.Start()

if ($StartGEV) { Start-GEVServer }

# --- message pump: keeps tray alive until Exit is chosen ---
[System.Windows.Forms.Application]::Run()
$timer.Stop()
$notifyIcon.Dispose()