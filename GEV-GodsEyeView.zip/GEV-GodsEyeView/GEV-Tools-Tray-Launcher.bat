﻿@echo off
setlocal

REM ============================================================
REM  God's Eye View - Tray Tool Launcher
REM  Double-click to launch the tray controller.
REM  Uses its own folder as the working directory, so this file
REM  works no matter where the gev-tools folder lives.
REM ============================================================

REM %~dp0 = this .bat's folder (with trailing backslash)
set "TOOLSDIR=%~dp0"

REM Make the script's own directory the working directory
cd /d "%TOOLSDIR%"

if not exist "GEV-Tray.ps1" (
    echo [ERROR] GEV-Tray.ps1 not found in %CD%
    echo         Expected location: %TOOLSDIR%
    pause
    exit /b 1
)

powershell -ExecutionPolicy Bypass -WindowStyle Hidden -NoProfile -File "GEV-Tray.ps1"

endlocal