﻿# Run-Doctor.ps1 - visible-console doctor wrapper
Set-Location "$HOME\godseyeview"
$ErrorActionPreference = "Continue"
npm run doctor 2>&1
$ErrorActionPreference = "Stop"
Write-Host "`nPress Enter to close..."
Read-Host