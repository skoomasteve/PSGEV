﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Prompts for free-tier API keys in priority order and wires them into
  God's Eye View's .env (insert-or-replace, preserving all other lines).
  Blank input = skip that provider. Finishes with npm run doctor.
#>
param([string]$InstallDir = "$HOME\godseyeview")

$ErrorActionPreference = "Stop"
$envFile = Join-Path $InstallDir ".env"
if (-not (Test-Path $envFile)) { throw ".env not found at $envFile. Run the installer first." }

# Variable name (must match .env.example) -> friendly description
$keyDefs = [ordered]@{
    "CESIUM_ION_TOKEN"     = "Cesium ion token (photorealistic 3D + terrain)"
    "AISSTREAM_API_KEY"    = "AISStream API key (live vessels)"
    "FIRMS_MAP_KEY"        = "NASA FIRMS map key (active fires)"
    "OPENSKY_CLIENT_ID"    = "OpenSky OAuth client ID"
    "OPENSKY_CLIENT_SECRET"= "OpenSky OAuth client secret"
    "TOMTOM_API_KEY"       = "TomTom developer key (real traffic)"
    "OPENSKY_AUTH_MODE"    = "OpenSky mode (anon = no signup, oauth = use your credentials)"
}

function Set-EnvValue([string]$File, [string]$Name, [string]$Value) {
    $lines = @(Get-Content $File)
    $found = $false
    $out = foreach ($line in $lines) {
        if ($line -match "^\s*$Name\s*=") { $found = $true; "$Name=$Value" }
        else { $line }
    }
    if (-not $found) { $out += "$Name=$Value" }
    Set-Content -Path $File -Value $out -Encoding UTF8
}

Write-Host "== God's Eye View key configurator ==" -ForegroundColor Cyan
Write-Host "Leave blank + Enter to skip a provider.`n"

foreach ($def in $keyDefs.GetEnumerator()) {
    if ($def.Key -eq "OPENSKY_AUTH_MODE") {
        $mode = Read-Host "OpenSky mode? Enter 'anon' (free, no signup) or 'oauth' (if you entered client credentials above)"
        if ($mode -in @("anon","oauth")) { Set-EnvValue $envFile $def.Key $mode; Write-Host "    set $def.Key=$mode" -ForegroundColor Green }
        continue
    }
    $val = Read-Host "Paste $($def.Value) [$($def.Key)]"
    if ([string]::IsNullOrWhiteSpace($val)) {
        Write-Host "    skipped" -ForegroundColor DarkGray
    } else {
        Set-EnvValue $envFile $def.Key $val.Trim()
        Write-Host "    saved to .env" -ForegroundColor Green
    }
}

# Re-apply owner-only perms (Set-Content recreates ACL inheritance)
icacls $envFile /inheritance:r /grant:r "$env:USERNAME`:F" | Out-Null

Write-Host "`n== Running setup doctor to verify each provider ==" -ForegroundColor Cyan
Push-Location $InstallDir
$ErrorActionPreference = "Continue"
npm run doctor 2>&1
$ErrorActionPreference = "Stop"
Pop-Location
Write-Host "`nDone. Providers showing [OK] are live; [--] were skipped." -ForegroundColor Green