﻿# Opens the free-tier key signup portals in priority order.
# NOTE: if a URL has moved, the authoritative links are in the repo's
# Keys & Costs doc and the comments in .env.example.
$portals = [ordered]@{
    "1. Cesium ion  (photorealistic 3D + terrain)" = "https://cesium.com/ion/signup"
    "2. AISStream   (live vessel tracking)"        = "https://www.aisstream.org/"
    "3. NASA FIRMS  (active fire detections)"      = "https://firms.modaps.eosdis.nasa.gov/"
    "4. OpenSky     (flight data, OAuth)"           = "https://www.opensky-network.org/"
    "5. TomTom      (real traffic data)"            = "https://developer.tomtom.com/"
}
foreach ($portal in $portals.GetEnumerator()) {
    Write-Host "$($portal.Key)  ->  $($portal.Value)" -ForegroundColor Cyan
    Start-Process $portal.Value
}
Write-Host "`nComplete the signups, then run Configure-GEV-Keys.ps1 to wire them in." -ForegroundColor Green