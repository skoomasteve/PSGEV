﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Creates a scheduled task that stops the God's Eye View dev server
  if it has been running continuously for longer than a time limit.
.DESCRIPTION
  The task runs every 30 minutes. If the server process started
  more than -MaxHours ago, it is killed. Your keys stay configured;
  only the server stops. Restart anytime with Start-GEV.bat.
.EXAMPLE
  .\Setup-GEV-AutoStop.ps1 -MaxHours 4    # kill after 4 hours
  .\Setup-GEV-AutoStop.ps1 -MaxHours 8    # more lenient
.EXAMPLE
  Unregister-ScheduledTask -TaskName "GEV-AutoStop" -Confirm:$false
#>

param(
    [int]$MaxHours = 4,
    [string]$InstallDir = "$HOME\godseyeview"
)

$ErrorActionPreference = "Stop"

# Watchdog script content
$watchdogScript = @"
param($InstallDir, $MaxHours)
$cutoff = (Get-Date).AddHours(-$MaxHours)
Get-CimInstance Win32_Process -Filter "Name='node.exe'" |
    Where-Object { $_.CommandLine -like "*$InstallDir*" } |
    ForEach-Object {
        if ($_.CreationDate -lt $cutoff) {
            Write-Output ("Stopping GEV server PID {0} (running since {1})" -f $_.ProcessId, $_.CreationDate)
            Stop-Process -Id $_.ProcessId -Force
        }
    }
"@

# Save the watchdog script
$scriptPath = "$HOME\godseyeview-watchdog.ps1"
Set-Content -Path $scriptPath -Value $watchdogScript -Encoding UTF8

# Create the scheduled task
$taskAction = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -File `"$scriptPath`" -InstallDir `"$InstallDir`" -MaxHours $MaxHours"

$taskTrigger = New-ScheduledTaskTrigger `
    -Once -At (Get-Date).AddMinutes(30) `
    -RepetitionInterval (New-TimeSpan -Minutes 30) `
    -Duration ([TimeSpan]::FromDays(365))

$taskPrincipal = New-ScheduledTaskPrincipal `
    -UserId $env:USERNAME `
    -LogonType Interactive `
    -RunLevel Limited

Unregister-ScheduledTask -TaskName "GEV-AutoStop" -Confirm:$false

Register-ScheduledTask `
    -TaskName "GEV-AutoStop" `
    -Action $taskAction `
    -Trigger $taskTrigger `
    -Principal $taskPrincipal `
    -Description "Stops God's Eye View dev server if running > $MaxHours hours (checked every 30 min)." `
    -Force | Out-Null

Write-Host "Scheduled task 'GEV-AutoStop' created." -ForegroundColor Green
Write-Host "  Server stopped after: $MaxHours hours of continuous running"
Write-Host "  Check interval:       every 30 minutes"
Write-Host "  Watchdog script:      $scriptPath"
Write-Host "`nTo remove:"
Write-Host "  Unregister-ScheduledTask -TaskName 'GEV-AutoStop' -Confirm:`$false"