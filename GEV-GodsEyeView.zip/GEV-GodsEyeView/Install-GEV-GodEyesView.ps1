﻿#Requires -Version 5.1
<#
.SYNOPSIS
  Installs God's Eye View (god's-eye-view) from source.
.DESCRIPTION
  Checks prerequisites (Git, Node.js 24.x >= 24.14.0, or 26.x) and installs
  missing ones WITHOUT Microsoft Store dependency. Uses Chocolatey
  or direct MSIs as fallback. Then clones repo, installs deps, creates .env.

.NOTES
  Requires administrative privileges for installing system packages.
#>

param(
    [string]$RepoUrl      = "https://github.com/bilawalsidhu/gods-eye-view.git",
    [string]$InstallDir   = "$HOME\godseyeview",
    [switch]$AllowDirectDownload,  # Allow direct MSI/EXE if choco unavailable
    [switch]$SkipChocoInstall      # Skip trying to install Chocolatey itself
)

$ErrorActionPreference = "Stop"
$NodeMin = "24.14.0"

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "    OK  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "    !!  $msg" -ForegroundColor Yellow }
function Write-Fail($msg)  { Write-Host "    XX  $msg" -ForegroundColor Red }

function Update-SessionPath {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath    = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Resolve-Command([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    while ($cmd -and ($cmd.CommandType -eq 'Alias' -or $cmd.CommandType -eq 'Function')) {
        $cmd = Get-Command $cmd.ResolvedCommandName -ErrorAction SilentlyContinue
    }
    return $cmd
}

# ===========================================================================
# Helper: Install Chocolatey (self-healing; handles broken remnants)
# ===========================================================================
function Ensure-Chocolatey {
    # 1. Already on PATH?
    if (Resolve-Command "choco") {
        Write-Ok "Chocolatey already installed ($(choco --version))"
        return $true
    }

    # 2. Probe standard locations for a WORKING choco.exe
    $chocoCandidates = @(
        "$env:ProgramData\chocolatey\bin\choco.exe"
        "$env:ProgramData\chocolatey\choco.exe"
        "$env:ChocolateyInstall\bin\choco.exe"
        "$env:ALLUSERSPROFILE\chocolatey\bin\choco.exe"
    ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

    if ($chocoCandidates) {
        $chocoDir = Split-Path $chocoCandidates[0]
        Write-Warn "choco.exe found at $chocoDir but not on PATH - fixing"
        $env:Path = "$chocoDir;$env:Path"
        # Persist to user PATH for future sessions (machine PATH needs elevation)
        $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
        if ($userPath -notlike "*$chocoDir*") {
            try { [Environment]::SetEnvironmentVariable("Path", "$userPath;$chocoDir", "User") } catch {}
        }
        if (Resolve-Command "choco") {
            Write-Ok "Chocolatey available ($(choco --version))"
            return $true
        }
    }

    if ($SkipChocoInstall) {
        Write-Warn "Chocolatey not found and installation skipped."
        return $false
    }

    # 3. Broken remnant: folder exists but no working choco.exe inside it.
    #    Quarantine it so the fresh installer doesn't refuse to proceed.
    if (Test-Path "$env:ProgramData\chocolatey") {
        Write-Warn "C:\ProgramData\chocolatey exists but contains no working choco.exe"
        $backup = "$env:ProgramData\chocolatey.broken.$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        try {
            Rename-Item "$env:ProgramData\chocolatey" $backup -ErrorAction Stop
            Write-Host "    Quarantined broken install to: $backup"
            Write-Host "    (Delete that folder once everything is working)"
        }
        catch {
            Write-Fail "Could not quarantine the broken Chocolatey folder ($_)."
            Write-Host  "    Close any programs using it, or rename it manually:"
            Write-Host  "    Rename-Item 'C:\ProgramData\chocolatey' 'chocolatey.broken'"
            return $false
        }
    }

    # 4. Fresh Chocolatey install (requires ELEVATED PowerShell)
    Write-Warn "Installing Chocolatey fresh..."
    Write-Host "    This requires elevated PowerShell. Please approve UAC if prompted."

    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

        Update-SessionPath

        # Re-probe PATH and filesystem after fresh install
        if (-not (Resolve-Command "choco")) {
            $fresh = "$env:ProgramData\chocolatey\bin\choco.exe"
            if (Test-Path $fresh) {
                $env:Path = "$(Split-Path $fresh);$env:Path"
            }
        }

        if (Resolve-Command "choco") {
            Write-Ok "Chocolatey installed: $(choco --version)"
            return $true
        }
        else {
            Write-Warn "Chocolatey install finished but choco still not resolvable."
            Write-Host "    Open a NEW PowerShell window and re-run this script."
            return $false
        }
    }
    catch {
        Write-Fail "Failed to auto-install Chocolatey: $_"
        return $false
    }
}

# ===========================================================================
# Helper: Install via Chocolatey
# ===========================================================================
function Install-WithChoco([string]$PackageId, [string]$DisplayName) {
    Write-Host "    Installing $DisplayName via choco..."
    choco install $PackageId --yes --no-progress --force
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "choco install of $PackageId failed (exit $LASTEXITCODE)."
        return $false
    }
    Update-SessionPath
    return $true
}

# ===========================================================================
# Helper: Install from direct MSI/EXE download
# ===========================================================================
function Install-DirectDownload([string]$Url, [string]$InstallerArgs, [string]$DisplayName, [string]$ExpectedPath) {
    if (Test-Path $ExpectedPath) {
        Write-Ok "$DisplayName already present at $ExpectedPath"
        Update-SessionPath
        return $true
    }

    if (-not $AllowDirectDownload) {
        Write-Fail "$DisplayName not found and direct download disabled."
        return $false
    }

    $tempFile = "$env:TEMP\$DisplayName-$((Get-Random)).exe"
    Write-Warn "Downloading $DisplayName to $tempFile..."

    try {
        Invoke-WebRequest -Uri $Url -OutFile $tempFile -UseBasicParsing -TimeoutSec 120
        Write-Host "    Installing $DisplayName silently..."
        Start-Process -FilePath $tempFile -ArgumentList $InstallerArgs -Wait -NoNewWindow
        
        Update-SessionPath
        
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        
        if (Test-Path $ExpectedPath -or (Resolve-Command (Split-Path $ExpectedPath -Leaf))) {
            Write-Ok "$DisplayName installed"
            return $true
        } else {
            Write-Warn "$DisplayName may have installed; check $ExpectedPath manually"
            return $false
        }
    }
    catch {
        Write-Fail "Direct download/install failed: $_"
        return $false
    }
}

# ===========================================================================
# 1. PREREQUISITE: Git (prefer choco, fallback to direct EXE)
# ===========================================================================
Write-Step "Checking for Git"

$git = Resolve-Command "git"
$gitPresent = $false

if ($git) {
    Write-Ok "Git present ($(git --version))"
    $gitPresent = $true
} elseif (Ensure-Chocolatey) {
    if (Install-WithChoco "git.install" "Git for Windows") {
        $git = Resolve-Command "git"
        if ($git) { Write-Ok "Git installed: $(git --version)"; $gitPresent = $true }
    }
}

if (-not $gitPresent -and $AllowDirectDownload) {
    Write-Warn "Chocolatey failed/missing; falling back to direct Git download..."
    $gitExe = "$env:ProgramFiles\Git\bin\git.exe"
    if (Install-DirectDownload `
            "https://github.com/git-for-windows/git/releases/download/v2.47.0.windows.3/Git-2.47.0.3-64-bit.exe" `
            "/VERYSILENT /NORESTART /NOCANCEL /SP-" `
            "Git" $gitExe) {
        Update-SessionPath
        $git = Resolve-Command "git"
        if ($git) { Write-Ok "Git installed: $(git --version)"; $gitPresent = $true }
    }
}

if (-not $gitPresent) {
    Write-Fail "Git not found and could not be installed automatically."
    Write-Host "    Manual options:"
    Write-Host "      - Chocolatey: choco install git.install (requires choco setup)"
    Write-Host "      - Direct:     https://git-scm.com/download/win"
    Write-Host "    Install manually, then re-run this script."
    exit 1
}

# ===========================================================================
# 2. PREREQUISITE: Node.js (24.x >= 24.14.0 or 26.x)
# ===========================================================================
Write-Step "Checking Node.js version (requires 24.x >= $NodeMin, or 26.x)"

function Get-NodeInfo {
    try {
        $raw = (node --version).TrimStart('v')
        $parts = $raw.Split('.')
        return @{ Major = [int]$parts[0]; Full = $raw; Path = (Get-Command node).Source }
    } catch { return $null }
}

$nodeInfo = Get-NodeInfo
$nodeOK = $false

if ($nodeInfo) {
    switch ($nodeInfo.Major) {
        24 {
            if ([version]$nodeInfo.Full -ge [version]$NodeMin) {
                Write-Ok "Node.js v$($nodeInfo.Full) meets requirement"
                $nodeOK = $true
            } else {
                Write-Warn "Node.js v$($nodeInfo.Full) is too old (< $NodeMin)"
            }
        }
        25 {
            Write-Warn "Node.js v$($nodeInfo.Full) is 25.x (EOL, unsupported)"
        }
        26 {
            Write-Ok "Node.js v$($nodeInfo.Full) meets requirement"
            $nodeOK = $true
        }
        default {
            Write-Warn "Node.js v$($nodeInfo.Full) found but not 24.x/26.x"
        }
    }
}

if (-not $nodeOK) {
    Write-Warn "Will attempt to install correct Node.js version"
    
    if (Ensure-Chocolatey) {
        # OpenJS.NodeJS.LTS tracks current LTS line (24.x as of this writing)
        if (Install-WithChoco "nodejs-lts" "Node.js LTS") {
            $nodeInfo = Get-NodeInfo
            if ($nodeInfo -and (($nodeInfo.Major -eq 24 -and [version]$nodeInfo.Full -ge [version]$NodeMin) -or $nodeInfo.Major -eq 26)) {
                Write-Ok "Node.js v$($nodeInfo.Full) now installed"
                $nodeOK = $true
            }
        }
    }

    # Fallback: direct Node.js LTS MSI
    if (-not $nodeOK -and $AllowDirectDownload) {
        Write-Warn "Chocolatey failed; falling back to direct Node.js LTS download..."
        $nodeMsi = "$env:SystemDrive\nodejs-lts.msi"
        # Get the latest 24.x LTS from nodejs.org dist directory
        $ltsVersion = "24.14.0"  # Can be updated as newer 24.x versions release
        $ltsUrl = "https://nodejs.org/dist/v$ltsVersion/node-v$ltsVersion-x64.msi"
        $nodeExe = "$env:ProgramFiles\nodejs\node.exe"
        
        if (Install-DirectDownload $ltsUrl "" "Node.js LTS" $nodeExe) {
            Update-SessionPath
            $nodeInfo = Get-NodeInfo
            if ($nodeInfo -and (([version]$nodeInfo.Full -ge [version]$NodeMin) -or $nodeInfo.Major -eq 26)) {
                Write-Ok "Node.js v$($nodeInfo.Full) now installed"
                $nodeOK = $true
            }
        }
    }

    if (-not $nodeOK) {
        Write-Fail "Node.js installation did not yield a usable version."
        Write-Host "    Current: $(if ($nodeInfo) { "v$($nodeInfo.Full) at $($nodeInfo.Path)" } else { 'not detected' })"
        Write-Host "    Manual options:"
        Write-Host "      - Chocolatey: choco install nodejs-lts"
        Write-Host "      - Direct:     https://nodejs.org (download LTS 24.x or 26.x)"
        Write-Host "    Install manually, then re-run this script."
        exit 1
    }
}

# ===========================================================================
# 3. Clone/update repository
# ===========================================================================
Write-Step "Fetching repository"

if (Test-Path $InstallDir) {
    if (Test-Path (Join-Path $InstallDir ".git")) {
        $answer = Read-Host "'$InstallDir' exists. Update via git pull? (y/n)"
        if ($answer -eq 'y') {
              Push-Location $InstallDir
    $ErrorActionPreference = "Continue"
    npm ci 2>&1
    $npmExit = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    Pop-Location
    if ($npmExit -ne 0) { throw "npm ci failed (exit $npmExit)" }
            Write-Ok "Repository updated"
        }
    } else {
        Write-Fail "'$InstallDir' exists but is not a git clone."
        Write-Host "    Move it aside or use -InstallDir to pick another path."
        exit 1
    }
} else {
    $ErrorActionPreference = "Continue"
    git clone $RepoUrl $InstallDir 2>&1
    $cloneExit = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    if ($cloneExit -ne 0) { throw "git clone failed (exit $cloneExit)" }
    Write-Ok "Cloned to $InstallDir"
}
# ===========================================================================
# 4. Install pinned dependencies
# ===========================================================================
Write-Step "Installing dependencies via npm ci (may take several minutes)"
Push-Location $InstallDir
$ErrorActionPreference = "Continue"   # npm talks loudly on stderr; don't treat as fatal
npm ci 2>&1
$npmExit = $LASTEXITCODE
$ErrorActionPreference = "Stop"       # restore strict mode for everything else
Pop-Location
if ($npmExit -ne 0) { throw "npm ci failed (exit $npmExit)" }
Write-Ok "Dependencies installed (lockfile-pinned)"
# ===========================================================================
# 5. Create .env
# ===========================================================================
Write-Step "Creating configuration"
$envFile = Join-Path $InstallDir ".env"
if (-not (Test-Path $envFile) -and (Test-Path "$InstallDir\.env.example")) {
    Copy-Item "$InstallDir\.env.example" $envFile
    icacls $envFile /inheritance:r /grant:r "$env:USERNAME`:F" | Out-Null
    Write-Ok ".env created (owner-only permissions)"
    Write-Host "    >>> Edit it: $envFile" -ForegroundColor Yellow
} elseif (Test-Path $envFile) {
    Write-Ok ".env exists - unchanged"
} else {
    Write-Warn ".env.example not found - create manually per README"
}

# ===========================================================================
# 6. Built-in setup doctor
# ===========================================================================
Write-Step "Running project setup doctor (npm run doctor)"
Push-Location $InstallDir
$ErrorActionPreference = "Continue"
npm run doctor 2>&1
$doctorExit = $LASTEXITCODE
$ErrorActionPreference = "Stop"
Pop-Location
if ($doctorExit -ne 0) { Write-Warn "Doctor reported issues, but continuing..." }

# ===========================================================================
# 7. Complete
# ===========================================================================
Write-Host ""
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host " Install complete!" -ForegroundColor Green
Write-Host ""
Write-Host "  Install Dir: $InstallDir"
Write-Host "  Launch:      Start-GEV.bat (double-click to run, close window to stop)"
Write-Host "  Uninstall:   Uninstall-GEV.ps1 (removes everything)"
Write-Host "  Auto-Stop:   Setup-GEV-AutoStop.ps1 (prevents forgotten sessions)"
Write-Host ""
Write-Host "=========================================================" -ForegroundColor Cyan