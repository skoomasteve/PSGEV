﻿==========================================
  GOD'S EYE VIEW - TRAY CONTROLLER
==========================================

WHAT THIS IS
  A lightweight system-tray manager for your local
  God's Eye View installation (C:\Users\<you>\godseyeview).
  It replaces manual terminal commands with a single
  icon that handles server start/stop, API setup,
  autostart, and diagnostics.

QUICK START
  1. Launch GEV-Tools-Launcher.bat (or double-click GEV-Tray.ps1)
  2. The tray icon appears in the bottom-right
  3. Double-click the icon → opens app or starts server
  4. Right-click the icon → full menu of controls

MENU OVERVIEW

  Status Line
    ● Server running  /  ○ Server stopped

  Server Controls
    ▶ Start server     — launches hidden background process
    ■ Stop server      — kills all GEV node.exe processes
    ↻ Restart server   — stop then start
    🌐 Open in browser — http://localhost:4173

  API Keys Submenu
    Acquire API keys (open signup portals)
    Enter / update API keys
    Run setup doctor
    Edit .env directly

  Start with Windows
    Tray + GEV server    — tray runs + server starts at boot
    Tray only (no server) — tray runs, server stays off
    Disabled             — removes from startup

  Utilities
    📋 View server log    — gev-server.log in Notepad
    ⚠ Reset ALL settings — deletes .env, restores template

  Exit
    Stops server (optionally), closes tray

TIPS
  • Server binds to localhost only (secure by default)
  • Double-click tray icon toggles between open/start
  • Server logs append to gev-server.log (view anytime)
  • Press F5 to refresh status in menu

TROUBLESHOOTING
  • Server won't start? Run "Run setup doctor" to diagnose.
  • "npm run dev" errors? Check gev-server.log contents.
  • Autostart broken? Re-create via "Start with Windows" menu.
  • Node.js 24.x/26.x required — installer checks this.

FILES
  GEV-Tray.ps1          — main tray controller
  Configure-GEV-Keys.ps1 — interactive key configurator
  Start-GEV-KeySignups.ps1 — opens signup portals
  Run-Doctor.ps1         — runs npm run doctor
  GEV-README.txt         — this file

SUPPORT
  GitHub: https://github.com/bilawalsidhu/gods-eye-view
  Security: https://github.com/bilawalsidhu/gods-eye-view/security
  Keys & Costs: See repo README → Keys & Costs section

==========================================
  End of README (press ESC to dismiss)
==========================================