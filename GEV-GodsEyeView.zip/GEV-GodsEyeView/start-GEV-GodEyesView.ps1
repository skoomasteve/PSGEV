﻿#Requires -Version 5.1
<# 
.SYNOPSIS
  Launches God's Eye View for a session. Press Ctrl+C in the console to stop it.
.DESCRIPTION
  Alternative to Start-GEV.bat for PowerShell users who prefer script
  over batch, or need to capture logs to a file.
.EXAMPLE
  .\Start-GEV.ps1                     # normal launch
  .\Start-GEV.ps1 -LogFile log.txt    # log output to file
#>

param(
    [string]$InstallDir = "$HOME\godseyeview",
    [string]$LogFile
)

if (-not (Test-Path (Join-Path $InstallDir "package.json"))) {
    Write-Host "Not installed at $InstallDir. Run Install-GEV.ps1 first." -ForegroundColor Red
    exit 1
}

Write-Host "Starting God's Eye View... (Ctrl+C in this window to stop)" -ForegroundColor Cyan
Write-Host "Note: server binds to localhost only. Do NOT add --host 0.0.0.0" -ForegroundColor DarkGray

Push-Location $InstallDir

try {
    if ($LogFile) {
        Start-Transcript -Path (Join-Path $InstallDir $LogFile) -Append
    }
    npm run dev
}
finally {
    Pop-Location
    if ($LogFile) {
        Stop-Transcript | Out-Null
    }
}